//2. Définissez toutes les entités requises dans votre IDE, en prenant soin de spécifier les types
pour les attributs et les paramètres des méthodes.

//les attributs:
//id => types int
// Nom, prenom, texte, affectation, resume_in, => types varchares  
//date => type DATETIME


 //les methodes sont "set" et "get"


// 3. BONUS, précisez le type de retour pour chacune de vos méthodes


// Méthode set pour modifier les valeurs des attributs 
// Méthode get pour obtenir les valeurs des attributs


